require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const helmet  = require('helmet');
const { apiLimiter } = require('./src/middleware/rateLimiter');

const app = express();
app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(express.json());
app.use('/api', apiLimiter);

app.use('/api/auth',     require('./src/routes/auth'));
app.use('/api/agents',   require('./src/routes/agents'));
app.use('/api/planning', require('./src/routes/planning'));

app.get('/health', (req, res) => res.json({ status: 'ok', ts: new Date() }));
app.use((req, res) => res.status(404).json({ error: 'Route introuvable' }));
app.use((err, req, res, next) => { console.error(err); res.status(500).json({ error: 'Erreur interne' }); });

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`API F2P.PMP sur http://localhost:${PORT}`));
